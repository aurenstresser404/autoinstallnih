
    const statsinterval = setInterval(function() {
        document.getElementById("output-server-status").innerHTML =  document.getElementById("server-status").innerHTML;
    
          }, 500);
    
    
    